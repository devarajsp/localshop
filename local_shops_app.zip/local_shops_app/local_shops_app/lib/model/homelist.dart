import 'package:best_flutter_ui_templates/design_course/home_design_course.dart';
import 'package:best_flutter_ui_templates/fitness_app/fitness_app_home_screen.dart';
import 'package:best_flutter_ui_templates/hotel_booking/hotel_home_screen.dart';
import 'package:flutter/widgets.dart';
import 'package:best_flutter_ui_templates/place_order/place_order_screen.dart';
import 'package:best_flutter_ui_templates/place_order/shopping_cart_screen.dart';


class HomeList {
  HomeList({
    this.navigateScreen,
    this.imagePath = '',
  });

  Widget navigateScreen;
  String imagePath;

  static List<HomeList> homeList = [
    HomeList(
      imagePath: 'assets/images/icon_place_order.png',
      navigateScreen: PlaceOrderScreen(),
    ),
    HomeList(
      imagePath: 'assets/images/icon_view_order.png',
      navigateScreen: ShoppingCartScreen(),
    ),
    HomeList(
      imagePath: 'assets/images/icon_discounts_and_offers.png',
      navigateScreen: DesignCourseHomeScreen(),
    ),
    HomeList(
      imagePath: 'assets/images/icon_your_messages.png',
      navigateScreen: DesignCourseHomeScreen(),
    ),
  ];
}
