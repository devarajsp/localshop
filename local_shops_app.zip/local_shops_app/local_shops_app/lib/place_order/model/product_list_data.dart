class ProductListData {
  ProductListData({
    this.imagePath = '',
    this.titleTxt = '',
    this.subTxt = "",
    this.dist = 1.8,
    this.reviews = 80,
    this.rating = 4.5,
    this.perNight = 180,
  });

  String imagePath;
  String titleTxt;
  String subTxt;
  double dist;
  double rating;
  int reviews;
  double perNight;

  factory ProductListData.fromJson(dynamic json) {
    return ProductListData(
      imagePath: '${json['imagePath']}',
      titleTxt: '${json['titleTxt']}',
      subTxt: '${json['subTxt']}',
      dist: double.parse('${json['dist']}'),
      reviews: int.parse('${json['reviews']}'),
      rating: double.parse('${json['rating']}'),
      perNight: double.parse('${json['perNight']}'),
    );
  }

  // Method to make GET parameters.
  Map toJson() => {
    'imagePath': imagePath,
    'titleTxt': titleTxt,
    'subTxt': subTxt,
    'dist': dist.toString(),
    'rating': rating.toString(),
    'reviews': reviews.toString(),
    'perNight': perNight.toString(),
  };

  static List<ProductListData> productList = <ProductListData>[];
  static List<ProductListData> filtered_productList = <ProductListData>[];
  static List<ProductListData> complete_productList = <ProductListData>[];
  List<ProductListData> GetFilteredList(String filterTxt)
  {
    print("Inside GetFilteredList() " + filterTxt);
    print(productList);
    return productList.where( (element)=> element.titleTxt.toLowerCase().contains(filterTxt.toLowerCase()) ).toList();
  }

  static List<ProductListData> productList1 = <ProductListData>[
    ProductListData(
      imagePath: 'assets/hotel/hotel_1.png',
      titleTxt: 'A-Hydrocort (hydrocortisone sodium succinate-injection)',
      subTxt: 'generic name - kamasu',
      dist: 2.0,
      reviews: 80,
      rating: 4.4,
      perNight: 180,
    ),
    ProductListData(
      imagePath: 'assets/hotel/hotel_2.png',
      titleTxt: 'Abilify (aripiprazole)',
      subTxt: 'generic name - mgasu',
      dist: 4.0,
      reviews: 74,
      rating: 4.5,
      perNight: 200,
    ),
    ProductListData(
      imagePath: 'assets/hotel/hotel_3.png',
      titleTxt: 'abacavir',
      subTxt: 'generic name - komatsu',
      dist: 3.0,
      reviews: 62,
      rating: 4.0,
      perNight: 60,
    ),
    ProductListData(
      imagePath: 'assets/hotel/hotel_4.png',
      titleTxt: 'Abreva (docosanol-topical)',
      subTxt: 'generic name - nomadsu',
      dist: 7.0,
      reviews: 90,
      rating: 4.4,
      perNight: 170,
    ),
    ProductListData(
      imagePath: 'assets/hotel/hotel_5.png',
      titleTxt: 'acamprosate calcium delayed-release tablet',
      subTxt: 'generic name - jombsy',
      dist: 2.0,
      reviews: 240,
      rating: 4.5,
      perNight: 200,
    ),
  ];
}
