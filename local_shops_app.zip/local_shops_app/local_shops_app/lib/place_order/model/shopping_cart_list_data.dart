class ShoppingCartListData {
  ShoppingCartListData({
    this.productName = '',
    this.costPerUnit = 1.8,
    this.numberOfUnits = 80,
    this.cost = 4,
  });

  String productName;
  double costPerUnit;
  double numberOfUnits;
  double cost;

  factory ShoppingCartListData.fromJson(dynamic json) {
    return ShoppingCartListData(
      productName: '${json['productName']}',
      costPerUnit: double.parse('${json['costPerUnit']}'),
      numberOfUnits: double.parse('${json['numberOfUnits']}'),
      cost: double.parse('${json['cost']}'),
    );
  }

  // Method to make GET parameters.
  Map toJson() =>
      {
        'productName': productName,
        'costPerUnit': costPerUnit.toString(),
        'numberOfUnits': numberOfUnits.toString(),
        'cost': cost.toString(),
      };

  static List<ShoppingCartListData> shoppingCartList = <ShoppingCartListData>[];

  List<ShoppingCartListData> GetFilteredList(String filterTxt)
  {
    print("Inside ShoppingCartListData GetFilteredList() " + filterTxt);
    print(shoppingCartList);
    return shoppingCartList.where( (element)=> element.productName.toLowerCase().contains(filterTxt.toLowerCase()) ).toList();
  }

}

