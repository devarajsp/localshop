class OrderListData {
  OrderListData({
    this.custName = '',
    this.custPhone = '',
    this.orderDate = '',
    this.orderDetails = '',
    this.orderStatus = ''
  });

  String custName;
  String custPhone;
  String orderDate;
  String orderDetails;
  String orderStatus;


  factory OrderListData.fromJson(dynamic json) {
    return OrderListData(
      custName: '${json['custName']}',
      custPhone: '${json['custPhone']}',
      orderDate: '${json['orderDate']}',
      orderDetails: '${json['orderDetails']}',
      orderStatus:'${json['orderStatus']}',
    );
  }

  // Method to make GET parameters.
  Map toJson() =>
      {
        'custName': custName,
        'custPhone': custPhone,
        'orderDate': orderDate,
        'orderDetails': orderDetails,
        'orderStatus':orderStatus
      };

  static List<OrderListData> orderListData = <OrderListData>[];
}